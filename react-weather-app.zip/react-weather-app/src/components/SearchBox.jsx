let React = require('react');

let SearchBox = React.createClass({    //Defining React component object
  getInitialState: function(){     //called only once when the component loads
    return {newSearchText:''};
  },
  onChange: function(e){
    this.setState({newSearchText: e.target.value});
  },
  render: function() {
    let inputStyle = {
      width: "90%",
      display: "inline-block",
      border: "none",
      background: this.props.backgroundColor,
      color: "#FFF"
    }

    let searchStyle = {
      width: "10%",
      textAlign: "center"
    }

    let todaysDate = {
      fontSize: "small",
      paddingLeft: 15
    }

    let date = new Date(this.props.date*1000);
    // Date format: MM/DD/YYYY
    let tDate = date.getMonth() + "/" + date.getDate() + "/" + date.getFullYear();
    // Hours part from the timestamp
    let hours = date.getHours();
    // Minutes part from the timestamp
    let minutes = "0" + date.getMinutes();
    // Seconds part from the timestamp
    let seconds = "0" + date.getSeconds();
    let formattedTime = hours + ':' + minutes.substr(-2) + ':' + seconds.substr(-2);

    return(
      <div className="form-group">
        <input style={inputStyle} type="text" className="form-control" id="usr" onChange={this.onChange} placeholder={this.props.location} value={this.state.newSearchText} /><i style={searchStyle} onClick={this.props.searchClick} className="fa fa-search" aria-hidden="true"></i>
        <p style={todaysDate}>{tDate} {formattedTime}</p>
      </div>
    );
  }
});

module.exports = SearchBox;
