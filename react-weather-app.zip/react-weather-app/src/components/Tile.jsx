let React = require('react');
let SearchBox = require('./SearchBox.jsx');

let ListItem = React.createClass({      //Defining React component object
  getInitialState: function(){          //called only once when the component loads
    return {searchStr: ''};
  },
  searchClick: function() {
    this.setState({searchStr: this.refs.searchBox.newSearchText});
  },
  checkIconCode: function(code){
    let wiClass= "";

    if(code === "01d"){
      wiClass="wi wi-day-sunny";
    }if(code === "02d"){
      wiClass="wi wi-day-cloudy";
    }if(code === "03d"){
      wiClass="wi wi-cloud";
    }if(code === "04d"){
      wiClass="wi wi-cloudy";
    }if(code === "09d"){
      wiClass="wi wi-day-showers";
    }if(code === "10d"){
      wiClass="wi wi-day-rain";
    }if(code === "11d"){
      wiClass="wi wi-day-thunderstorm";
    }if(code === "13d"){
      wiClass="wi wi-day-snow";
    }if(code === "50d"){
      wiClass="wi wi-day-fog";
    }if(code === "01n"){
      wiClass="wi wi-night-clear";
    }if(code === "02n"){
      wiClass="wi wi-night-partly-cloudy";
    }if(code === "03n"){
      wiClass="wi wi-night-cloudy";
    }if(code === "04n"){
      wiClass="wi wi wi-cloudy";
    }if(code === "09n"){
      wiClass="wi wi-night-showers";
    }if(code === "10n"){
      wiClass="wi wi-night-rain";
    }if(code === "11n"){
      wiClass="wi wi-night-thunderstorm";
    }if(code === "13n"){
      wiClass="wi wi-night-snow";
    }if(code === "50n"){
      wiClass="wi wi-night-fog";
    }

    return wiClass;
  },
  render: function() {
    let colHeight = {
      maxHeight: 470
    }

    let panelMargin = {
      margin: "10px 0",
      borderRadius: "4px"
    }

    let panelHeaderStyle = {
      background: this.props.headerColor,
      border: `1px solid ${this.props.headerColor}`,
      borderRadius: "4px",
      color: "#FFF"
    }

    let panelBodyRowColor1 = {
      background: "#EBEBEB"
    }

    let panelBodyRowColor2 = {
      background: "#f5f5f5"
    }

    let paddingTop10 = {
      paddingTop: 10
    }

    let paddingTop15 = {
      paddingTop: 15
    }

    let code = "10d";

    let iconUrl = "http://openweathermap.org/img/w/10d.png";

    let temp=1543838400;

    let wiClass = this.checkIconCode(code);

    console.log(`iconClass: ${wiClass}`);

    console.log(`Tile Component --- weatherObjects: ${JSON.stringify(this.props.weatherData.list[0].dt)}`);    //<---- HERE IT CRASHES

    return (
      <div style={colHeight} className="col-md-15">
          <div id={this.props.index} style={panelMargin} className="panel">
            <div style={panelHeaderStyle} className="panel-header">
              <div className="row">
                <div className="col-xs-12 col-md-12">
                  <SearchBox date={temp} location={this.props.location} backgroundColor={panelHeaderStyle.background} searchClick={this.searchClick} ref="searchBox"/>
                </div>
                <div className="col-xs-6 col-md-6 weather-icon">
                  <h1 className="text-center"><i className={wiClass}></i></h1>
                </div>
                <div className="col-xs-6 col-md-6 temperature">
                  <h1 className="text-center">25<sup>&#176;</sup></h1>
                </div>
              </div>
              <div className="row">
                <div className="col-xs-6 col-md-7 wind-speed-humidity">
                  <h4 className="text-center" className="text-center"><i className="wi wi-wind-beaufort-1"> 7mph NE</i></h4>
                </div>
                <div className="col-xs-6 col-md-5 wind-speed-humidity">
                  <h4 className="text-center" className="text-center"><i className="wi wi-humidity"> 25%</i></h4>
                </div>
              </div>
            </div>
            <div className="panel-body">
              <div className="row">
                <div className="col-md-12">
                  <div style={panelBodyRowColor1} className="row">
                    <div className="col-xs-6 col-md-6">
                      <p className="text-center" style={paddingTop10}>25 August</p>
                    </div>
                    <div className="col-xs-2 col-md-2">
                      <i style={paddingTop15} className="fa fa-sun-o" aria-hidden="true"></i>
                    </div>
                    <div className="col-xs-4 col-md-4">
                      <p className="text-center" style={paddingTop10}>12<sup>&#176;</sup> / 28<sup>&#176;</sup></p>
                    </div>
                  </div>
                </div>
                <div className="col-md-12">
                  <div style={panelBodyRowColor2} className="row">
                    <div className="col-xs-6 col-md-6">
                      <p className="text-center" style={paddingTop10}>25 August</p>
                    </div>
                    <div className="col-xs-2 col-md-2">
                      <i style={paddingTop15} className="fa fa-sun-o" aria-hidden="true"></i>
                    </div>
                    <div className="col-xs-4 col-md-4">
                      <p className="text-center" style={paddingTop10}>12<sup>&#176;</sup> / 28<sup>&#176;</sup></p>
                    </div>
                  </div>
                </div>
                <div className="col-md-12">
                  <div style={panelBodyRowColor1} className="row">
                    <div className="col-xs-6 col-md-6">
                      <p className="text-center" style={paddingTop10}>25 August</p>
                    </div>
                    <div className="col-xs-2 col-md-2">
                      <i style={paddingTop15} className="fa fa-sun-o" aria-hidden="true"></i>
                    </div>
                    <div className="col-xs-4 col-md-4">
                      <p className="text-center" style={paddingTop10}>12<sup>&#176;</sup> / 28<sup>&#176;</sup></p>
                    </div>
                  </div>
                </div>
                <div className="col-md-12">
                  <div style={panelBodyRowColor2} className="row">
                    <div className="col-xs-6 col-md-6">
                      <p className="text-center" style={paddingTop10}>25 August</p>
                    </div>
                    <div className="col-xs-2 col-md-2">
                      <i style={paddingTop15} className="fa fa-sun-o" aria-hidden="true"></i>
                    </div>
                    <div className="col-xs-4 col-md-4">
                      <p className="text-center" style={paddingTop10}>12<sup>&#176;</sup> / 28<sup>&#176;</sup></p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
      </div>
      );
  }
});

module.exports = ListItem;
