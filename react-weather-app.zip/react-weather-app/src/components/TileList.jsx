let React = require('react');
let Tile = require('./Tile.jsx');
let HTTP = require('../services/httpservice');
let Json = require('circular-json');

let List = React.createClass({    //Defining React component object
    getInitialState: function() {
      return{location:'Madrid, Spain', weatherData:''};
    },
    getCity: function() {
      setState({location: this.refs.tile.searchStr});
    },
    componentWillMount: async function() {
      let list = [];

      await HTTP.get(`q=${this.state.location}&cnt=5&units=imperial&appid=3ff527abfa8edebc287dd4bcf540c174`)
        .then(function(data){
          this.setState({
            weatherData: data
          });
        }.bind(this));  //bind callback to the react component's 'this'
    },
    render: function() {
      let tileList1 = [];
      let tileList2 = [];

      let tileHeaderColors = ['#ec4444', '#79b7ae', '#e68e4f', '#a6a43b', '#f27e7f', '#817871', '#367db5', '#357cb4', '#9770a7', '#ce4571', '#3f3f3f'];

      let rowWidth = {
        width: "95%",
        margin: "auto"
      }

      let colMarginBottom = {
        marginBottom: 80
      }

      for(i=0; i<5; i++){
        let panelIndex = `panel-${i}`;
        tileList1.push(<Tile index={panelIndex} location={this.state.location} headerColor={tileHeaderColors[Math.floor(Math.random() * 10) + 1]} weatherData={this.state.weatherData} ref="tile" />);
      }

      for(i=0; i<5; i++){
        let panelIndex = `panel-${i}`;
        tileList2.push(<Tile index={panelIndex} location={this.state.location} headerColor={tileHeaderColors[Math.floor(Math.random() * 10) + 1]} weatherData={this.state.weatherData} ref="tile" />);
      }

      console.log("TileList Component --- weatherObjects : " + JSON.stringify(this.state.weatherData.list[0].dt));  //<---- HERE IT CRASHES


      return(
        <div className="col-md-12">
          <div style={rowWidth} className="row">
            <div className="col-md-12 top-line">
              <div className="row">
                {tileList1}
              </div>
            </div>
            <div className="col-md-12 bottom-line">
              <div className="row">
                {tileList2}
              </div>
            </div>
          </div>
        </div>
      );
    }
});

module.exports = List;
