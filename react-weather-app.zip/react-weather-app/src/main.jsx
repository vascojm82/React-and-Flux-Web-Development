let React = require('react');
let ReactDOM = require('react-dom');
let WeatherApp = require('./components/WeatherApp.jsx');

ReactDOM.render(<WeatherApp />, document.getElementById('main'));     //this.prop.title in ListManager component
